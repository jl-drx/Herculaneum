# nnInteractive sheet refinement

Refines an existing segmentation of papyrus sheets in a Herculaneum scroll volume using
[nnInteractive](https://github.com/MIC-DKFZ/nnInteractive).

The input is one mask covering all sheets. The output is one label per sheet.

| volume | input mask | refined | overlaid |
|:---:|:---:|:---:|:---:|
| ![volume](img/img.png) | ![input mask](img/gt.png) | ![refined](img/refined.png) | ![overlaid](img/both.png) |

## Pipeline

**Multilabel map from the binary segmentation.**
[cc3d](https://github.com/seung-lab/connected-components-3d) turns the binary mask into one label
per sheet using face connectivity. Labels that still hold two sheets fused across a bridge get
separated by eroding until they part, then handing every voxel to the nearest eroded core.

**Centerlines.** A sheet is a few voxels thick, so its centerline is a surface running down the
middle of it: the ridge of the distance transform, with the window and tolerance scaled to the
sheet's own half-thickness. The same extraction runs on the background between the sheets and gives
a surface down the middle of every gap.

**Refine.** Each sheet goes through nnInteractive with three prompts:

| prompt | content |
|---|---|
| previous segmentation | the sheet's mask |
| negative scribble | centerlines of the two gaps flanking the sheet |
| positive scribble | the sheet's own centerline |

The positive scribble is submitted last, since nnInteractive centres the prediction on the most
recent interaction and gives it the most weight. The image is normalised once and reused across all
sheets.

## Install

```bash
pip install -r requirements.txt
```

Needs a CUDA GPU. The checkpoint is downloaded on first run into `~/.nninteractive`.

## Usage

```bash
python seg-refinement.py -i 1407735_img.tif -s 1407735_seg.tif -o 1407735_seg_refined.tif
```

Both inputs are 3D TIFFs of matching shape. The mask can be binary or multi-label. A JSON report
with per-sheet voxel counts, dice against the input and timings lands next to the output.

To keep the intermediates:

```bash
python seg-refinement.py -i 1407735_img.tif -s 1407735_seg.tif -o 1407735_seg_refined.tif \
    --save-centerlines centerlines.tif \
    --save-prompts prompts/ \
    --save-components components/
```

`--save-prompts` writes what the model was shown for each sheet: `1` = mask, `2` = positive
centerline, `3` = gap centerlines. Useful for checking a sheet that came out wrong.

`--limit N` refines only the N largest sheets. `--help` lists the rest.
