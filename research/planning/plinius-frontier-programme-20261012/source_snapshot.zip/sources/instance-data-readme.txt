A brief explanation of the contents of volumetric-instance-labels/

instance-labels/

    - A subset of Scroll 1, chunked into 256x256x256 cubes, each in .nrrd format.
    - The cubes are manually annotated to label each sheet of papyrus with a distinct instance ID.
    - Each cube folder is labelled as z_y_x:
        - z_y_x_volume.nrrd contains the raw scroll data from the CT scan (the input).
        - z_y_x_mask.nrrd contains the corresponding instance labels (could be used as training data for model output).

instance-labels-harmonized/ *** RECOMMENDED STARTING POINT ***

    - The same cubes from instance-labels/ but with instance IDs updated such that the ID values are consistent across cube boundaries.
    - In the process of making continuous instances across all cubes sharing faces, chunks of papyrus beneath a specific size threshold
      were removed from the data set. We do not expect this to affect anything. 
    - A trained model capable of generating instance labels from an input CT volume could be a great starting point for segmentation
      methods.
    - As this is the recommended starting point for this data, instance-labels-harmonized.zip is also provided for easy download.
	
semantic-labels/

    - A larger set of 256x256x256 cubes that were used as inputs to the instance labeling process:
        - For z=1744 the entire cross section of the scroll is included.
        - For all other z a reduced cross section is included, centred around the scroll axis.
    - Each cube folder is labelled as z_y_x:
        - z_y_x_volume.nrrd contains the raw scroll data.
        - z_y_x_mask.nrrd contains the corresponding semantic mask, generated using a 3D U-Net. Instead of separating the papyrus sheets
          from one another, this just separates foreground (papyrus) from background (air).

Please reach out to the Vesuvius Team on our discord server with any questions. And thanks for showing up :)
