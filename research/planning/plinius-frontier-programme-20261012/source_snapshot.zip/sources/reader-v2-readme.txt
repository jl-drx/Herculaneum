# Reader v2: beats every public 9 µm ink model on the 116 keV First Letters scan protocol

A drop-in for the team's own `ink_9um` inference command: only the checkpoint changes. It reads a scroll it never
saw, and beats the team's released checkpoint on every held-out test.

Checkpoint: [huggingface.co/domenicor046/reader-v2](https://huggingface.co/domenicor046/reader-v2) | Dense native
labels: [huggingface.co/datasets/domenicor046/reader-v2-labels](https://huggingface.co/datasets/domenicor046/reader-v2-labels)

![Letters invisible in the raw CT, found by Reader v2 where the team's reference map has them](figures/banner_116keV.png)

*A held-out segment of PHerc0009B at 8.64 µm / 116 keV, the scan protocol of 11 of the 22 First Letters scrolls
(other segments of this fragment were in training). No letters can be seen in the raw CT, yet Reader v2 reads them
from that CT alone. The reference comes from a 2.4 µm / 77 keV scan of the same papyrus, a scan that 20 of the 22 First Letters
scrolls do not have: it is the answer a 9 µm model should get close to. The 11 × 16 mm window was chosen from that
reference map, not from any prediction.*

- **Beats every public 9 µm model on the 116 keV scans**, the protocol of 11 of the 22 First Letters scrolls: AUC
  **0.834** on four held-out PHerc0009B segments vs **0.725** for the next best, and **0.927** vs **0.901** against
  human labels.
- **Fewest false alarms:** at the same 80% ink recall it flags **10.4%** of a blank papyrus segment as ink, **5×
  less** than Hecate (58%) and **4× less** than the best released checkpoint (43%). False ink is what sends a First
  Letters search chasing phantom letters.
- **Reads a scroll it never saw:** on PHerc0841, AUC **0.858** against the team's 2.4 µm map, the highest of any
  public model, and **0.824** against human labels vs **0.733** for the best released checkpoint.
- **Drop-in:** same architecture, config format and inference CLI as the team's `ink_9um`. Runs directly on native
  9.36 µm and 8.64 µm scans. One 138 MB checkpoint, MIT.

## Scoreboard

Every test held out; same data, same masks, same metric for every model.

| held-out test | **Reader v2** | released `ink_9um` (best of 14) | best other public model |
|---|---|---|---|
| **116 keV** PHerc0009B, AUC vs team map (4 segments) | **0.834** | 0.626 | 0.725 (Hecate) |
| **116 keV** PHerc0009B, AUC vs human labels | **0.927** | 0.813 | 0.901 (Nieuwlaar) |
| **False alarms** on blank papyrus (at 80% ink recall) | **10.4%** | 43% | 10.5% (Nieuwlaar) |
| **Never-seen scroll** PHerc0841, AUC vs team map | **0.858** | 0.708 | 0.848 (Hecate) |
| **113 keV** PHerc0139 w047, AUC | 0.893 | 0.778 | 0.898 (Nieuwlaar) |
| **Never-seen scroll** PHerc0841, AUC vs human labels | 0.824 | 0.733 | 0.855 (Hecate) |

**First on four of the six tests, second on the other two, and ahead of the team's released checkpoint on all six.**

<details>
<summary>Full table: every public 9 µm model on every test</summary>

| held-out test | **Reader v2** | Hecate 9.6 µm (team) | Nieuwlaar dense-native | ink9um-dense (my August model) | released `ink_9um` (best of 14) |
|---|---|---|---|---|---|
| 116 keV PHerc0009B, AUC vs team map (4 segments) | **0.834** | 0.725 | 0.725 | 0.698 | 0.626 |
| 116 keV PHerc0009B, AUC vs human labels (1 segment) | **0.927** | 0.884 | 0.901 | 0.873 | 0.813 |
| False alarms on blank papyrus (w053, at 80% ink recall) | **10.4%** | 58% | 10.5% | 20% | 43% |
| Never-seen scroll PHerc0841, AUC vs the team's 2.4 µm map | **0.858** | 0.848 | 0.802 | 0.769 | 0.708 |
| 113 keV PHerc0139 w047 (outside all label sets), AUC | 0.893 | 0.777 | **0.898** | 0.870 | 0.778 |
| Never-seen scroll PHerc0841, AUC vs human labels (3 segments) | 0.824 | **0.855** | 0.800 | 0.771 | 0.733 |

PHerc0841 is marked as validation data in the team's own label sets. Hecate was run on renders resampled to 9.6 µm,
as its model card requires. Per-segment numbers are in `results/`; `python scripts/verify_release_numbers.py` checks
every number in this README against them.

</details>

## The whole page, every model

![The whole held-out 116 keV segment, every public 9 µm model](figures/whole_segment_116keV.png)

*The banner's held-out 116 keV segment (PHerc0009B), whole and uncropped, every public 9 µm model with the same
contrast stretch. Reader v2 recovers text rows across the whole page, where the reference has them; the other
models recover mainly the bottom rows.*

## Up close: the same letters, every model

![Native-resolution zoom at 116 keV](figures/zoom_116keV_letters.png)

*The banner's held-out 116 keV segment at native resolution, every model with the same contrast stretch, in the
11 × 29 mm box with the most ink in the reference map (chosen from the reference, not from any prediction). No letters
are visible in the raw CT; Reader v2 puts the letters of "ΟΜΑΖ" and of the row above where the reference has them
(orange overlay, top right).*

## The never-seen scroll: all three PHerc0841 segments

![All three PHerc0841 segments](figures/full_0841_segments.png)

*All three labelled segments of PHerc0841, not only the best one. Reader v2 shows the text lines where the reference
has them; the released checkpoint mostly sees texture.*

## Blank papyrus: 4–5× fewer false alarms than the team's models

![False alarms on blank papyrus](figures/false_alarms.png)

*A known blank segment (top, raw CT on the left) and real ink (bottom), every model at its own 80% ink-recall
threshold. Hecate and the released checkpoint paint the blank papyrus as ink. One 19 × 19 mm crop; the scoreboard gives
the pooled rates.*

## Get it and run it

If you already run the team's `ink_9um` models, only the checkpoint changes:

```bash
hf download domenicor046/reader-v2 reader-v2-step040000.pth --local-dir .
python -m koine_machines.inference.infer <surface_volume.zarr> reader-v2-step040000.pth out.tif \
  --overlap 0.5 --blend-mode hann --direction forward
```

`koine_machines` is the team's package: `ink-detection/` on the `merge-ink-pipelines` branch of
[villa](https://github.com/ScrollPrize/villa), installed with `pip install -e ink-detection` (it also needs villa's
`vesuvius` package). On Windows add `--no-compile`.

## Two optional modes

**Best quality** (3× inference time): the same team command on three 17-layer depth windows (centred and ±2
layers), averaged. Settings fixed in advance. PHerc0841 0.824 → **0.834** (all three segments improve), 116 keV
0.837, false alarms unchanged at 10.4%.

```bash
python scripts/infer_best_quality.py <surface_volume.zarr> reader-v2-step040000.pth out.tif
```

**With Hecate**: the plain mean of Reader v2 and Hecate (weights from
[scrollprize/hecate](https://huggingface.co/scrollprize/hecate); the script resamples to 9.6 µm for Hecate as its
card requires). Fixed in advance, no tuning. Best numbers on the never-seen scroll (0.866) and on 116 keV human labels
(0.935), at the cost of more false alarms (31.8% vs 10.4%).

```bash
python scripts/infer_with_hecate.py <surface_volume.zarr> reader-v2-step040000.pth <hecate_dir> out.tif --um 9.362
```

## Why it works

The open data holds seven objects whose native 8–9 µm scans are registered, by the team's own meshes, to a
sharper ink map from a finer scan. Reader v2 is trained on dense labels from those maps across six of them, on each
scan's own native renders (no resampling), and the seventh (PHerc0841) is held out entirely. It builds on
my August release, [ink9um-dense](https://github.com/DomRusso2/ink9um-dense), which won a Progress Prize: the same
dense-label recipe, taken from 9.6 µm renders of the original corpus to the native scans of six objects, and
training starts from that model.

| object | native scan | segments (train / held out) | teacher map |
|---|---|---|---|
| PHerc0139 | 9.362 µm, 113 keV | 20 / 0 (benchmark segments excluded) | 2.399 µm, 78 keV |
| PHerc0814 | 9.362 µm, 113 keV | 8 / 0 | 2.399 µm |
| PHerc0500P2 | 9.362 µm, 113 keV | 18 / 2 | 2.215 µm |
| PHerc0009B | 8.64 µm, 116 keV | 14 / 4 | 2.401 µm |
| PHerc0343P | 8.64 µm, 116 keV | 6 / 2 | 2.215 µm |
| PHerc0172 | 7.91 µm, 53 keV | 4 / 2 | same-scan team map |
| **PHerc0841** | 9.366 µm, 113 keV | **0 / 3, the whole scroll** | 2.403 µm + human labels |

Plus the original `ink_9um` corpus. Labels: ink where the team map is ≥ 128, supervised where it is ≥ 128 or
≤ 64. Every object passed an alignment gate. Recipe: the released `aligned21_hybrid_3d2d` config with only the
datasets and per-object batch quotas changed, 40k iterations (`train_config.json`). `scripts/v2_run.py` rebuilds
data, labels, training and the evaluation suite from the public bucket, resumably.

## Also in this release

- **Dense native labels for 70 segments of six objects** (the training labels of Reader v2):
  [domenicor046/reader-v2-labels](https://huggingface.co/datasets/domenicor046/reader-v2-labels). Same zarr layout as
  the team's `ink_9um` labels, so they drop into a training config by changing one path.
- **A calibrated text screen** (`scripts/textscore2.py`) that separates known text from blank papyrus and artefacts,
  and a First Letters sweep with it over all 340 community meshes of the eight eligible 9 µm scrolls
  (`results/textscore2_040000.csv`). No text on those meshes yet: the flags were surface crossings and crushed zones,
  so the surfaces, not the reader, are the bottleneck there.

## Reproduce

- **Check the numbers:** `python scripts/verify_release_numbers.py` compares every number in this README with the
  per-segment results in `results/`, and exits non-zero on any mismatch.
- **Re-score a checkpoint:** `python scripts/v2_run.py fetch` downloads the evaluation data from the public bucket (surface
  volumes, team maps, human labels); `v2_run.evaluate(tag, checkpoint)` runs the same suite for any `ink_9um`-format
  checkpoint, and `scripts/hecate_eval.py` does it for Hecate. The 113 keV crops come from `scripts/bkill.py`.
- **Retrain:** `train_config.json` is the exact config (paths relative to the project root). It starts from
  `reader-v2-init-ft12k.pth` on the Hugging Face page (my August ink9um-dense checkpoint fine-tuned 12k steps at
  116 keV by `scripts/p009b_train_config.py`) and trains on the dense labels above plus the `ink_9um` corpus with the
  [ink9um-dense](https://huggingface.co/domenicor046/ink9um-dense-labels) labels.
- The scripts find the team's code through `VILLA` (a villa checkout on `merge-ink-pipelines`) and Hecate through
  `HECATE_DIR`; set `PYTHON` to pick the interpreter.

## Limits

- One training seed; checkpoint-to-checkpoint noise on the PHerc0841 mean is about 0.01.
- Teacher maps are model outputs from finer scans; human labels exist on 4 of the evaluation segments.
- The 116 keV test segments are held out, but other segments of PHerc0009B were in training. No labelled 116 keV
  scroll is fully held out yet.
- On PHerc0841's human labels Hecate alone scores higher than Reader v2 alone (0.855 vs 0.824). Nieuwlaar's model
  is within 0.1 points on false alarms (10.5% vs 10.4%) and slightly ahead at 113 keV (0.898 vs 0.893).
- On PHerc1447, where the team reported letters, Reader v2 shows one letter-like form, not readable lines.
