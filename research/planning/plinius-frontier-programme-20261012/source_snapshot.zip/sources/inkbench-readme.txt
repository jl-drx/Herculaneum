# inkbench: what the public ink models really do on held-out human labels, and two cheap ways to beat the recommended checkpoint

**Every number here is reproducible from the scripts in this folder on one 8 GB GPU (RTX 4060 Ti).**

Who did what: Alex Clark, working solo, set the direction and the two ideas tested here (checkpoint averaging, ink transplant). The code and the runs were done with Claude, an AI coding assistant, in the same way the villa repo's own AGENTS.md describes. Every result was checked against human labels, and the failures are reported alongside the wins.

## Summary

1. **A single "soup" checkpoint matches or beats the recommended one on every held-out region, at the same inference cost.** Averaging the weights of seed 42's checkpoints into one file raises mean held-out average precision from 0.79 to 0.85 on human labels (full-canvas runs). Most of that gain is on pherc0139-w016; on the other two regions the soup ties the recommended checkpoint (+0.002, +0.001). The 14-checkpoint output average is the recipe that wins on all three.
2. **Averaging all 14 public checkpoints does better still (0.87)**, and on the cropped runs, averaging their outputs with the 2 µm production model does best (0.85 to 0.86 vs 0.83 for the 14-average alone). The 2 µm model alone scores 0.80 on the same pixels. The averaging gain also shows up on a fourth scroll outside the training set (PHerc0343P, agreement with its official read +0.09 Pearson over the recommended checkpoint on its one non-thick segment).
3. **The late checkpoints memorize.** They beat early ones on training pixels and lose on held-out pixels. Fine-tuning further on the same labels makes held-out scores worse from any starting point.
4. **A stop-sign preflight** flags surface renders that never isolate one sheet of papyrus; every such render gave noise from the ink model.
5. Two ideas failed and are documented: teaching a 9 µm student from 2 µm maps on an unseen scroll, and every clever ensemble weighting scheme (plain averaging wins).

The ensemble idea came from Alex Clark: ink leaves a footprint distinct from bare papyrus, so when equally trained models disagree on a faint scroll, ask several and trust where they agree.

## What "held-out" means here

From the checkpoint config, the `ink_9um` models trained on labeled segments from four scrolls (PHerc0139, PHerc0814, PHerc1667, PHercParis4). The only pixels never used in training are the `_validation_mask` regions on three segments: pherc0139-w016, pherc0814-46527, pherc1667-w029, about 465,000 pixels in total. Those are the test set for every human-label number below. Chance AP on them is 0.23 to 0.32.

**Related work, found after our runs.** [khj1222/vesuvius-challenge](https://github.com/khj1222/vesuvius-challenge) independently scored all 14 `ink_9um` checkpoints on these same three masks with threshold-swept F1 (docs/14: "the honest ceiling is F1 ~0.74-0.77", memorization gaps of 0.22 to 0.45, a noise floor of about 0.03 F1 per split), audited the masks (docs/17: on pherc0139-w016 "99.1% of its held-out pixels lie within two patches of a training pixel"; only pherc1667-w029 has real spatial separation; so these masks measure intra-segment performance, not cross-scroll generalization), and retrained leave-one-scroll-out (docs/15: the cross-scroll gap "is bias, not variance", peaks at 20k steps and overtrains by 75k; ensembling recovers almost nothing across scrolls). They did not test ensembles or weight averaging on the held-out masks. This repo is that missing arm, and we adopt their caveat: every held-out number below is near-training performance within labeled segments. Our checkpoint-curve finding (Finding 3) matches their leave-one-scroll-out result independently.

To be comparable with their scorecard, here is the same held-out set in their metric, best threshold-swept F1, on full canvases:

| recipe | pherc0814-46527 | pherc1667-w029 | pherc0139-w016 | mean F1 |
|---|---|---|---|---|
| recommended single (seed42, step 75k) | 0.753 | 0.852 | 0.531 | 0.712 |
| single seed42 step 20k | 0.761 | 0.802 | 0.742 | 0.768 |
| soup (seed42 steps 10k, 20k, 30k) | 0.772 | 0.829 | 0.731 | 0.777 |
| average of all 14 | 0.781 | 0.860 | 0.740 | 0.793 |
| 2 µm production model | 0.862 | 0.753 | 0.595 | 0.737 |
| 2 µm + 14-average + soup | 0.843 | 0.840 | 0.749 | **0.811** |

The soup sits at the top of their single-checkpoint ceiling; the 14-average and the cross-resolution mix clear it. The mean gains (0.06 to 0.10 F1) are above their 0.03 noise floor.

**Does the gain survive far from training pixels?** Distance from each held-out pixel to the nearest training-supervision pixel, AP per band, full canvases (`f1_sweep.py --full`):

| segment, band | pixels | recommended | soup | 14-average | 2 µm |
|---|---|---|---|---|---|
| pherc1667-w029, far, more than 384 px | 125,689 | 0.901 | 0.902 | **0.927** | 0.827 |
| pherc0139-w016, near, up to 128 px | 105,720 | 0.589 | 0.763 | **0.832** | 0.519 |
| pherc0139-w016, mid, 128 to 384 px | 72,426 | 0.658 | **0.850** | 0.784 | 0.795 |
| pherc0814-46527, near, up to 128 px | 72,525 | 0.804 | 0.726 | 0.785 | **0.901** |
| pherc0814-46527, mid, 128 to 384 px | 88,526 | 0.865 | 0.863 | 0.877 | **0.930** |

Read plainly: on the one region with real spatial separation from training pixels (pherc1667-w029), the 14-average still wins but by a modest margin (+0.026) and the soup gains nothing. The large gains are on pherc0139-w016, whose held-out pixels sit close to training pixels. So the honest statement is: averaging helps most where the model has seen the neighborhood, and helps a little where it has not. It never hurt on the far region.

## Double test: full canvases, no crops

The 14-checkpoint tables below were run on crops around the labeled regions (256 px margin). As a check, the three key recipes were re-run on the full segment canvases and scored on the same held-out pixels:

| region (full canvas) | recommended single | soup (seed42 steps 10k, 20k, 30k) | average of all 14 |
|---|---|---|---|
| pherc0814-46527 | 0.839 | 0.841 | **0.860** |
| pherc1667-w029 | 0.901 | 0.902 | **0.927** |
| pherc0139-w016 | 0.622 | 0.808 | **0.808** |
| mean | 0.787 | 0.850 | **0.865** |

The ranking holds on every region: average of 14, then soup, then the recommended checkpoint. The numbers themselves move: the recommended checkpoint scores much higher on pherc1667-w029 at full canvas than on its crop (0.901 vs 0.758), so the cropped tables understate it there and the soup's margin on that region is small at full canvas. Treat this table as the primary result and the cropped tables as the per-checkpoint detail. (`fullcanvas_check.py`)

## Cross-scroll check: a fourth scroll the models never saw

khj1222's audit is right that the three held-out regions sit inside labeled segments of training scrolls, so they measure near-training performance. To test the ensemble claim outside the training set we ran the same recipes on PHerc0343P, which is not one of the four training scrolls and ships an official 2 µm ink prediction per segment in the open-data bucket. The official map is a dense grayscale prediction, not a hand label, so the metric is agreement with the official read (Pearson on the papyrus footprint, and the fraction of our top 1% pixels that land in its top 1%), not AP.

Of the eight PHerc0343P segments with a 9 µm surface volume, seven are "thick" by the stop-sign preflight and one is borderline. On the borderline one, the ensemble beats the recommended checkpoint on both measures; on a thick one, every recipe is at chance:

| segment (sheetcheck) | recipe | Pearson vs official | top-1% overlap (chance 0.01) |
|---|---|---|---|
| 20250511003658 (unclear, 18/31 layers dense) | recommended single (seed42, step 75k) | +0.195 | 0.139 |
| 20250511003658 | soup (seed42 steps 10k, 20k, 30k) | +0.277 | 0.092 |
| 20250511003658 | **average of all 14** | **+0.288** | **0.223** |
| 20250902171204 (thick, 25/31) | recommended single | -0.004 | 0.007 |
| 20250902171204 (thick) | average of all 14 | +0.030 | 0.025 |

![cross-scroll 0343P](figures/cross_scroll_0343P.png)
*PHerc0343P segment 20250511003658. Left: official 2 µm read, pooled to 9 µm. Middle: recommended 9 µm checkpoint. Right: 14-checkpoint average.*

Read plainly: on a scroll outside the training set, averaging still beats the recommended checkpoint (+0.09 Pearson, +0.08 overlap), which is the direction the held-out tables predict, and the absolute agreement is low because the render is nearly thick. On the thick render nothing recovers anything, which is the stop sign doing its job on a fourth scroll. This is one readable segment, so it is a supporting data point, not a headline. (`cross_scroll_0343P.py`, `cross_scroll_0343P.csv`)

We also looked for a clean segment nobody had read yet, to make a first read. There is none in the open data: every segment that has a surface volume already has an ink map from a scroll-specific model (PHerc0172, "Scroll 5", has two timesformer reads on a 7.91 µm surface), and the segments without ink have only meshes, which need the heavy rendering that gave thick volumes on PHerc1447. (`hunt_unread.py`)

## Finding 1: soup and ensembles vs the recommended checkpoint (human labels, held-out pixels)

| checkpoint or recipe | pherc0814-46527 | pherc1667-w029 | pherc0139-w016 | mean AP |
|---|---|---|---|---|
| recommended single (seed42, step 75k) | 0.846 | 0.758 | 0.687 | 0.764 |
| best single (seed42, step 20k) | 0.837 | 0.886 | 0.753 | 0.826 |
| **soup: weights of seed42 steps 10k, 20k, 30k, one file** | 0.883 | 0.869 | 0.705 | 0.819 |
| soup: weights of seed42 steps 10k to 75k, one file | 0.861 | 0.861 | 0.720 | 0.814 |
| average of the 4 early checkpoints (outputs) | 0.850 | 0.864 | 0.760 | 0.825 |
| **average of all 14 checkpoints (outputs)** | 0.841 | 0.888 | 0.758 | 0.829 |

![held-out bars](figures/gt_bars.png)

Block-bootstrap 95% intervals for the gain over the recommended checkpoint: 14-average on pherc1667-w029 +0.130 [+0.073, +0.207], on pherc0139-w016 +0.071 [+0.007, +0.136], on pherc0814-46527 -0.005 [-0.053, +0.045]. Soup (10k to 75k) on pherc1667-w029 +0.104 [+0.033, +0.202]; the other two regions lean positive with intervals crossing zero.

Soups are trajectory-dependent: the seed-43 soups help less (all seven 0.753; steps 10k to 30k 0.785), a two-checkpoint seed-42 soup (10k, 20k) scores 0.817, and averaging weights across seeds collapses (0.300), as expected for models in different basins. `soup.py` rebuilds the soup files deterministically from the public checkpoints (138 MB each, not stored here).

Cross-check on the 19-segment canonical-map set: the early soup scores 0.160 mean agreement against 0.156 for the 14-average and 0.088 for the recommended checkpoint, and matches the 14-average on the never-seen scroll PHerc0500P2 (0.166 vs 0.170).

## Finding 2: the 2 µm production model, and mixing resolutions

We ran `scrollprize/ink_canonical_2um` on 2.399 µm crops around the same three regions, pooled its output 4x, and scored the same pixels.

| region | 2 µm production model | 9 µm recommended | 9 µm soup | 9 µm 14-average | 2 µm + 9 µm 14-average | 2 µm + 14-average + soup |
|---|---|---|---|---|---|---|
| pherc0814-46527 | **0.922** | 0.846 | 0.883 | 0.841 | 0.896 | 0.907 |
| pherc1667-w029 | 0.827 | 0.758 | 0.869 | **0.889** | 0.877 | 0.886 |
| pherc0139-w016 | 0.640 | 0.687 | 0.705 | 0.758 | 0.774 | **0.785** |
| mean | 0.796 | 0.764 | 0.819 | 0.829 | 0.849 | **0.859** |

The 9 µm average matches or beats the 2 µm production model overall. Mixing resolutions is the best mean and never the worst on any region; every equal-weight mix we tried lands between 0.849 and 0.859 (`cross_res.py`), so the gain is from mixing, not from a recipe. No weights were chosen on these pixels.

![letters](figures/letters_1667_label_rec_ens_2um_mixed.png)
*pherc1667-w029, held-out region. Human label, recommended 9 µm, 9 µm 14-average, 2 µm model, mixed.*

Caveat: the 2 µm model card does not say what it trained on. If it saw these validation pixels, its numbers are inflated, which makes the comparison conservative for the 9 µm side. The 2 µm run used their default 62-layer window and tile 256 without tuning.

## Finding 3: memorization, from both sides

On the training pixels of the same segments the recommended step-75k checkpoint scores AP 0.86 and step-20k scores 0.84. On held-out pixels the order flips: 0.76 vs 0.83.

Fine-tuning further on those three segments (6,000 steps, batch 16, learning rate 0.001, validation pixels excluded from supervision) lowered held-out AP from every start: soup 0.819 to 0.737; recommended 0.764 to 0.726. Souping the fine-tuned checkpoints recovered only part of it (0.759, 0.742). The public checkpoints are already past the point where more of the same data helps.

On the canonical-map set, both seeds show the same shape on the never-seen scroll PHerc0500P2: highest agreement at step 10k, decaying with training, while the home scroll keeps improving.

![training curve](figures/training_curve.png)

## How faint the ink is in the raw scan

On the three labeled segments, the raw intensity at human-labeled ink pixels differs from labeled background by only 0.2 to 0.3 standard deviations at the best layer, and the sign flips between scrolls (ink slightly brighter on pherc1667-w029, slightly darker on pherc0814-46527 and pherc0139-w016). Local roughness differs by 0 to 9 percent. A human eye needs roughly a full standard deviation to see anything. This is why letter-shaped patterns people see in the flattened scan are fibers and cracks, and why the detectors have to work from 3D texture rather than brightness. (`ink_signal.py`)

## Finding 4: the sheet stop sign

103 segments with a ~9 µm surface volume profiled straight from S3 at low resolution (`sheetcheck.py`). Six "thick" renders (papyrus dense at every layer, contrast below 1.12) were run through the ink model: all six gave noise. Non-thick beat thick (Mann-Whitney p = 0.006). Inside the non-thick group the score does not rank quality, so it is a stop sign, not a grade. Of 19 PHerc0814 auto-grown 9.362 µm renders, 15 were thick.

![sheet scatter](figures/scatter.png)

## Synthetic ink by transplant: failed in this form

Idea (Alex): take real ink with its true 3D fingerprint and put it through new surroundings so the model learns ink, not one scroll. Implementation (`synth_ink.py`): 137 windows of real labeled writing from the training regions, each carried as a 21-layer residual stack (voxel minus local papyrus background), pasted with flips, small rotations, scaling and gain onto blank papyrus: the labeled segments' own training background (in-domain) and ten PHerc0500P2 renders where the 14-checkpoint ensemble was confident there is no ink (cross-scroll). 61 to 201 glyphs per target, 100k to 335k synthetic ink pixels each. Fine-tuned the seed-42 early soup for 4,000 steps.

| training data | held-out human AP (mean of 3) | canonical agreement on 3 held-out 0500P2 renders |
|---|---|---|
| soup start | 0.819 | 0.201 |
| real training labels + synthetic, all 13 targets | 0.630 | 0.145 |
| synthetic on the unseen scroll only | 0.341 | 0.045 |

Both got worse on every measure, and the cross-scroll-only run collapsed. The prior-art sweep predicted the likely causes: the donor stacks come from 2.399 µm scans pooled to 9.6 µm while the 0500P2 hosts are native 9.362 µm scans of a different scroll, so the fringe scale and noise texture do not match; pasted residuals carry the donor's surface texture and a seam, which are easier to learn than ink; and mixing donors whose ink is brighter than papyrus with hosts where it is darker teaches nothing coherent. A second attempt did those three things: in-plane smoothed residuals so only the depth profile transfers, feathered seams, and hosts limited to the three matched labeled segments (`synth_ink.py --v2`). Against the fair control, the same fine-tune on real labels only, it still lost: held-out AP 0.683 vs 0.732 after 4,000 steps, 0.700 vs 0.759 for the soups of saved checkpoints. Conclusion for now: transplanted ink, even depth-profile-only and seam-blended, teaches something the real held-out ink does not share. Synthetic ink for this problem remains open, and both attempts are in the repo so nobody has to repeat them.

## What did not work

- **Teacher-student on an unseen scroll.** Pseudo-labels from the canonical 2.4 µm maps of ten PHerc0500P2 renders (ink above 128, background below 40) and 4,000 fine-tuning steps from the soup: held-out human AP fell to 0.42 to 0.50, and agreement on three held-out 0500P2 renders fell from 0.201 to 0.117 to 0.168. At 9 µm those renders may not carry the ink signal the 2.4 µm model sees.
- **Clever ensembling.** Rank averaging equals z-averaging (0.830 vs 0.829). Leave-one-region-out weights: 0.823 to 0.825. Keeping only the top 4 or 7 checkpoints: 0.807 to 0.808, worse. Gaussian blur of the map: no gain. Strict consensus (every model must agree): much worse.
- **Shade cards instead of a network.** Give every pixel its 21 shades through the sheet (plus the same with local brightness removed), learn ink vs not from training pixels with logistic regression or by grouping similar cards (k-means, 64 groups), score on held-out pixels: AP 0.42, 0.27, 0.23 against chance 0.37, 0.32, 0.23. Adding a 7x7 neighbourhood average did not help. The best single shade alone: 0.40, 0.40, 0.31. The neural models on the same pixels: 0.84, 0.90, 0.62. Ink is not a shade or a stack of shades at one spot; it is a spatial texture across tens of pixels in 3D, which is exactly what the networks learn and what no per-pixel rule can see. (`shade_test.py`)
- **Test-time tricks.** Mirror flipping helps a single model a little (0.764 to 0.781) and does nothing for the ensemble. Averaging over three depth windows adds about 0.006.
- **The only unmapped scroll.** PHerc1447 has 9 µm renders and no canonical map. Three of its four renders are thick; the fourth shows two dense bands. The 14-checkpoint average on it produced bright arcs hugging the edges of holes, the usual failure artifact. No ink claim.

**Disagreement as an uncertainty map.** The per-pixel standard deviation across the 14 checkpoints correlates with the ensemble's error on every region (r = +0.46, +0.58, +0.57). It highlights stroke edges and ambiguous blobs. `disagreement.py`, `figures/disagreement_1667.png`.

## Recoverability: can we tell "no ink" from "ink not recovered"? (first pass)

Their open problem in one line. We ran the soup on 54 native 9.362 µm renders from four scrolls that have canonical maps and asked what predicts how much real ink it recovers (agreement with the canonical map), using only things available on an unread scroll.

- **Render geometry alone barely predicts it.** Sheet contrast, band width and peak offset each correlate with recovery at about ±0.3, but a leave-one-scroll-out model on them has rank correlation 0.21 and does not beat guessing the mean. Inside the biggest scroll (31 renders of PHerc0500P2) contrast has no relation to recovery at all. Which scroll a render comes from explains 30 percent of the variance. The stop sign holds only at the extreme: renders dense at every layer average 0.09 vs 0.16 for the rest, and 3 of 15 still reach 0.2.
- **The model's own output does better, and one label-free number does best.** Run two checkpoints of different seeds on the render and correlate their maps. That two-model agreement predicts real recovery with rank correlation +0.50 across 51 renders, and one threshold (agreement above 0.60) separates "some real ink" from "noise" 75 percent of the time against a 59 percent majority baseline, leave-one-scroll-out. Two more label-free signatures help: the brightest pixels hugging the edges of holes in the papyrus (noise does, ink does not; +0.47) and spatial smoothness of the map at 8 px (+0.43). A ridge model on all of them reaches rank correlation 0.42 leave-one-scroll-out and beats the mean guess (MAE 0.084 vs 0.096).

![two-model agreement](figures/recov_two_model.png)

These are small-sample results (54 renders, 4 scrolls) and are a first pass. The two-model check costs two inferences and no labels, so it is the one piece here already usable on an unread scroll: if two seeds disagree about a render, do not spend annotator time on its ink map. Applied to the only unmapped scroll, PHerc1447, the two models agree at 0.34, below the threshold: noise, matching what the eye saw. On the readable PHerc0139 title they agree at 0.71. (`recov_collect.py`, `recov_second.py`, `recov_model.py`, `recov_output.py`, `recov_figure.py`, `recov_table.csv`)

## Cost on an 8 GB card

Measured on this RTX 4060 Ti: one 9 µm checkpoint covers the full pherc0814-46527 canvas (2130 x 3455 pixels at 9.6 µm) in about 17 seconds, so the soup costs 17 seconds and the 14-average about 4 minutes. The 2 µm model needed 57 seconds for a crop that covers about 4 percent of that canvas, roughly 80 times more GPU time per unit area than one 9 µm checkpoint. The soup is the cheap default; the mix is for when 2 µm output already exists.

## Recommendation

For 9 µm ink inference today: run the soup checkpoint (or `ensemble_infer.py --recipe all` when GPU time allows) instead of the single recommended checkpoint, run `sheetcheck.py` first, and where 2 µm data exist, average the 2 µm output in. For training: select checkpoints by held-out AP, not step count; more data from new scrolls, not more steps on old ones.

## Tools in this repo

- `sheetcheck.py`: stop-sign preflight for surface renders.
- `soup.py`: builds the soup checkpoints from the public ones and scores them.
- `ensemble_infer.py`: one command, several checkpoints, averaged output, stop sign built in.
- `gt_eval.py`, `gt_crop.py`, `pool_local.py`, `labels_clean.py`, `readz2.py`, `metrics_np.py`: the held-out human-label benchmark (pooling 2.399 µm volumes to 9.6 µm, cropping to labeled regions, plain-numpy metrics).
- `sweep_ckpt.py`, `ensemble2.py`, `study_select.py`, `study_run.py`, `curve_plot.py`: the 19-segment canonical-map study.
- `dl_2um_crop.py`, `infer_2um.py`, `cross_res.py`: the 2 µm comparison.
- `variants_run.py`, `variants_eval.py`, `loo_weights.py`, `smooth_test.py`, `disagreement.py`, `gt_boot.py`, `gt_boot2.py`: the extra experiments above.
- `finetune_*.json`, `ft_eval.py`, `pseudo_labels.py`, `canon_eval_ckpts.py`: the training experiments.
- `cross_scroll_0343P.py`, `hunt_unread.py`: the fourth-scroll check and the search for unread clean segments.

## Limitations, stated plainly

- Three held-out regions, about 465,000 labeled pixels, is the entire held-out human-label set that exists for these models.
- Held-out runs were made on crops around the labeled region (256 px margin); on pherc0814-46527 the crop changed AP by about 0.01 and no ranking.
- Canonical-map agreement compares a 9 µm model against a stronger 2.4 µm model's map, not against human labels.
- Two label chunk files for pherc0139-w016 (of about 3,000) came down as zero bytes and were treated as empty.
- One segment (PHerc0814 20260226123353) has an empty canonical map and was excluded from the 19-segment set.
- Windows notes in `SETUP.md`: the `volume-cartographer` C++ package is not needed for ink work; data-loader workers must be 0 for the 2 µm pipeline and for monkey-patched runs; a Smart App Control policy blocked scipy's DLLs mid-project, which is why the metrics are plain numpy.

## Reproduce

See `SETUP.md` for the folder layout. Then:

```
python study_select.py; python sweep_ckpt.py; python ensemble2.py; python curve_plot.py
python pool_local.py <2.399um zarr key> <seg>; python gt_crop.py GT2_<seg> labels/aligned/<seg> GTC_<seg>
python gt_eval.py GTC_<seg> labels_crop/<seg> --ckpts all; python gt_summary.py; python soup.py
python dl_2um_crop.py <seg> <2.399um zarr key>; python infer_2um.py <seg>; python cross_res.py
python ensemble_infer.py data/<seg>/layers.zarr out/<seg> --recipe all
```

Data: `s3://vesuvius-challenge-open-data` (anonymous). Models: `scrollprize/ink_9um`, `scrollprize/ink_canonical_2um`. Labels: `scrollprize/datasets` under `ink_9um/labels`.
