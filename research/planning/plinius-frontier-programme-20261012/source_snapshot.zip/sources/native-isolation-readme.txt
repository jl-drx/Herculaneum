# Keep excluded ink annotations out of native training targets

A correction for [villa's native ink pipeline](https://github.com/ScrollPrize/villa), with a reproducible experiment on public scroll data.

Existing held-out ink changed native training targets in **22 of 61 mixed training crops** from PHerc0139 and PHerc1667. With the patch, **zero of those crops** depend on the excluded labels. Actual CT input, surface geometry, and partition masks stay fixed.

![Native targets before and after](figures/native_targets_before_after.png)

## Motivation

I used an AI-assisted workflow to explore improvements to native ink detection. That led to a problem with how excluded annotations were being used in training. We reproduced it on real data from two scrolls, verified the fix, and packaged the tests and before/after evidence so others can check it. The value is straightforward: more reliable experiments before researchers spend time and compute training models.

— Miika Kestilä. [Contribution and AI-assistance note](COMMENTARY.md).

## Review and reproduce

- [Report: evidence, mechanism, and limits](REPORT.md)
- [Source patch](patches/native-supervision-isolation.patch)
- [Reproduction instructions](REPRODUCE.md)
- [Complete replay bundle, including data](https://github.com/Mickey123123/vesuvius-native-supervision-isolation/releases/tag/v1.0.0)
- [Original real-data results](evidence/portable-before-full.json) and [patched results](evidence/portable-after-full.json)
- [Original console log](evidence/portable-before-full.log) and [patched console log](evidence/portable-after-full.log)
- [Full ink test output](evidence/tests/ink_suite_final_v2.log)
- [Input provenance and data license](THIRD_PARTY_NOTICES.md)

The portable test detects the defect in **28/28 mode/role/crop cases** on the original source and **0/28** after applying this patch to a fresh source tree. The full ink suite passes **302 tests**, with two optional teacher-checkpoint tests skipped. The 32 new regression cases yield 24 failures and 8 passing controls before the fix, and all pass afterward.

The patch changes four production Python files, documents the behavior, updates cache-version expectations, and adds regression tests. It preserves physical model inputs and permitted positive annotations. Subtiling validation membership changes intentionally; adopting the patch requires rebuilt caches and a new validation baseline.

This establishes an annotation-exclusion correctness improvement. It does not demonstrate improved model accuracy, identify a released checkpoint as affected, or produce a new reading. All scientific runs used the documented Linux aarch64/Python 3.12/Torch 2.14 CPU environment. The repository's declared Python 3.14 environment was not fully validated.

**Baseline:** `ScrollPrize/villa@b218ace879d3239a63047e1e2039f327929d283e`.

The source, reproducer, and documentation are MIT licensed. Scroll data and derived visualizations retain their source terms, including CC BY-NC 4.0. See [attribution](THIRD_PARTY_NOTICES.md). The code repository omits the `data/` directory; the release bundle includes all 496 input files.
