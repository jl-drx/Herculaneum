fiber-skeletons

This is a dataset of manually annotated papyrus fibers - the individual strands that make up a papyrus sheet.

Cubes of size 256^3 or 512^3 were selected from within the scroll, and inside each cube, every papyrus fiber was traced and labeled.

They are traced (or "skeletonized") using the WEBKNOSSOS browser annotation software.

The directory structure follows the nnU-Net dataset format: https://github.com/MIC-DKFZ/nnUNet/blob/master/documentation/dataset_format.md.

The fibers have been converted to a volumetric/voxelized representation to be used as inputs to machine learning or other methods that expect 3D image data.
This script performs the conversion and generates the dataset: https://github.com/ScrollPrize/villa/tree/main/foundation/datasets/fibers-dataset.

Additionally, the original skeletonized fibers from WEBKNOSSOS are available in Dataset001_sk-fibers-20250124/nml and follow the WEBKNOSSOS NML format: https://docs.webknossos.org/webknossos/data/concepts.html#nml-files.
