import concurrent.futures, datetime, hashlib, json, pathlib, sys, urllib.request
from html.parser import HTMLParser

OUT = pathlib.Path('/workspace/herculaneum-lab/reports/plinius-frontier-programme-20261012/sources')
OUT.mkdir(parents=True, exist_ok=True)

class Plain(HTMLParser):
    def __init__(self):
        super().__init__(); self.parts=[]; self.links=[]; self.skip=0
    def handle_starttag(self, tag, attrs):
        if tag in ('script','style'): self.skip += 1
        if tag in ('p','div','h1','h2','h3','h4','li','tr','section','br'): self.parts.append('\n')
        if tag == 'a':
            href=dict(attrs).get('href')
            if href: self.links.append(href)
    def handle_endtag(self, tag):
        if tag in ('script','style'): self.skip=max(0,self.skip-1)
    def handle_data(self, text):
        if not self.skip: self.parts.append(text)

def fetch(item):
    key,url=item
    receipt={'id':key,'requested_url':url,'accessed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    try:
        req=urllib.request.Request(url,headers={'User-Agent':'Plinius-research-review/1.0','Accept':'text/html,application/json,text/plain,*/*'})
        with urllib.request.urlopen(req,timeout=40) as r:
            data=r.read(8*1024*1024+1)
            if len(data)>8*1024*1024: raise ValueError('Review source exceeds 8 MiB cap')
            receipt.update(status=r.status, final_url=r.url, content_type=r.headers.get('Content-Type'))
        path=OUT/(key+'.raw');path.write_bytes(data)
        receipt.update(bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),file=path.name)
        text=data.decode('utf-8',errors='replace')
        if '<html' in text[:5000].lower() or '<!doctype' in text[:500].lower():
            p=Plain();p.feed(text)
            text='\n'.join(line.strip() for line in ''.join(p.parts).splitlines() if line.strip())
            (OUT/(key+'.links.json')).write_text(json.dumps(p.links,indent=2)+'\n')
        (OUT/(key+'.txt')).write_text(text)
    except Exception as exc:
        receipt.update(error_type=type(exc).__name__,error=str(exc))
    (OUT/(key+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
    return receipt

if __name__=='__main__':
    items=json.loads(pathlib.Path(sys.argv[1]).read_text())
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        for receipt in pool.map(fetch,items): print(json.dumps(receipt),flush=True)
